#ifndef REGCHECK_H_
#define REGCHECK_H_

void register_checker(void);

#endif // REGCHECK_H_
